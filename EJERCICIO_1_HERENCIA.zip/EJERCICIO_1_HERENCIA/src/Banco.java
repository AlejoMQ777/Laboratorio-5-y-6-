import java.util.ArrayList;

public class Banco {
    private ArrayList<Cuenta> listaCuentas;

    public Banco() {
        listaCuentas = new ArrayList<>();
    }

    public void agregarCuenta(Cuenta cuenta) {
        listaCuentas.add(cuenta);
    }

    public void operacionDeposito(Cuenta cuenta, long monto) {
        cuenta.deposito(monto);
    }

    public void operacionRetiro(Cuenta cuenta, long monto) {
        if (cuenta instanceof Ahorro) {
            ((Ahorro) cuenta).retirar(monto);
        } else if (cuenta instanceof Corriente) {
            ((Corriente) cuenta).retirar(monto);
        }
    }

    public void informeCuentas() {
        for (Cuenta c : listaCuentas) {
            System.out.println(c.toString());
        }
    }
}
