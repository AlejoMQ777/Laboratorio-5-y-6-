
public class Cuenta {
	private int numero;
	private Persona titular;
	private long saldo;
	public Cuenta(int numero, Persona titular, long saldo) {
		super();
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
	}
	public Cuenta(int numero2, Persona titular2) {
		// TODO Auto-generated constructor stub
	}
	public Persona getTitular() {
		return titular;
	}
	public void setTitular(Persona titular) {
		this.titular = titular;
	}
	public long getSaldo() {
		return saldo;
	}
	public void setSaldo(long saldo) {
		this.saldo = saldo;
	}
	@Override
	public String toString() {
		return "Cuenta [numero=" + numero + ", titular=" + titular + ", saldo=" + saldo + "]";
	}
	
	

}
