public class Corriente extends Cuenta {
    private long sobregiroPermitido;

    public Corriente(int numero, Persona titular, long sobregiroPermitido) {
        super(numero, titular);
        this.sobregiroPermitido = sobregiroPermitido;
    }

    public void retirar(long monto) {
        if (monto > 0 && getSaldo() + sobregiroPermitido >= monto) {
            deposito(-monto);
        }
    }

    private void deposito(long l) {
		// TODO Auto-generated method stub
		
	}

	@Override
    public String toString() {
        return "Cuenta Corriente -> " + super.toString() + 
               ", Sobregiro permitido=" + sobregiroPermitido;
    }
}

