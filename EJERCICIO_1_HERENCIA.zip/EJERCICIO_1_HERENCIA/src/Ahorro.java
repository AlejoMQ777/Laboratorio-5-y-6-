public class Ahorro extends Cuenta {
    private static final double TASA_INTERES = 0.03;

    public Ahorro(int numero, Persona titular) {
        super(numero, titular);
    }

    public void aplicarInteres() {
        long interes = (long) (getSaldo() * TASA_INTERES);
        deposito(interes);
    }

    private void deposito(long interes) {
		// TODO Auto-generated method stub
		
	}

	public void retirar(long monto) {
        if (monto > 0 && monto <= getSaldo()) {
            deposito(-monto);
        }
    }

    @Override
    public String toString() {
        return "Cuenta Ahorro -> " + super.toString();
    }
}
