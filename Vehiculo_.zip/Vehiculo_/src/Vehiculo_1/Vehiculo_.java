package Vehiculo_1;

public interface Vehiculo_ {

}
