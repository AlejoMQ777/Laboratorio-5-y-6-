package Vehiculo_1;

public class Vehiculo {

}
