package Vehiculo_1;

public class Moto_ {

}
